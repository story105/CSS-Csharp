﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CheckingsAccountAssignmentCharlesStory
{
    class Savings : Account
    {
        private int interest;
        public Savings(int balance, int interest):base(balance)
        {
            this.interest = interest;
        }

        public void setInterest(int interest)
        {
            this.interest = interest;
        }
        public int getInterest()
        {
            return interest;
        }

        public override string ToString()
        {
            return "Saving Account: " + balance + ", the interest: " + interest;

        }
    }
}

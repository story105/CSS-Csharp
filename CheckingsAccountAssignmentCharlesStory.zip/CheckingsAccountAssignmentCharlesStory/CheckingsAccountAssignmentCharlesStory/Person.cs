﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CheckingsAccountAssignmentCharlesStory
{
    class Person
    {
        private string name = string.Empty;

        private Checkings accountC;
        private Savings accountS;

        public Person(String name, Checkings accountC, Savings accountS)
        {
            this.name = name;
            this.accountC = accountC;
            this.accountS = accountS;
        }

        public void setName(string name)
        {
            this.name = name;
        }
        public string getName()
        {
            return name;
        }
        public void setCheckingsAccount(Checkings accountC)
        {
            this.accountC = accountC;
        }
        public Checkings getCheckingsAccount()
        {
            return accountC;
        }
        public void setSavingsAccount(Savings accountS)
        {
            this.accountS = accountS;
        }
        public Savings getSavingsAccount()
        {
            return accountS;
        }


        public override string ToString()
        {
            return "Account of " + name + ":" + "\n Account infochecking: " + accountC.ToString() + ", saving " + accountS.ToString();

        }
    }
}

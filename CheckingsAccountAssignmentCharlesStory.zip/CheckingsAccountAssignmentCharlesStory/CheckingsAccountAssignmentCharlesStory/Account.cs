﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CheckingsAccountAssignmentCharlesStory
{
    class Account
    {
        public int balance;
        private int amount;

        public Account(int balance)
        {
            this.balance = balance;
        }

        public void getBalance(int balance)
        {
            this.balance = balance;
        }
        public int getBalance()
        {
            return (balance);
        }


        public int deposit(int amount)
        {
            this.amount = amount;
            balance = balance + amount;
            return balance;
        }

        public bool withdraw(int amount)
        {
            this.amount = amount;
            if (amount <= balance)
            {
                balance = balance - amount;
                return true;
            }
            else
            {
                return false;
            }

        }

        public override string ToString()
        {
            return "Your balance is " + balance;

        }
    }
}

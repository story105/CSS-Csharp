﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CheckingsAccountAssignmentCharlesStory
{
    class Program
    {
        static void Main(string[] args) 
        {
            Checkings AccountBobChecking = new Checkings(0);
            Savings AccountBobSaving = new Savings(0, 0);
            Checkings AccountAChecking = new Checkings(0);
            Savings AccountASaving = new Savings(0, 0);
            

            // Person p = new Person("", Account, Account); ////This is just an example for myself 
            
            Person Bob = new Person("bob", AccountBobChecking, AccountBobSaving);
            Person Alice = new Person("Alice", AccountAChecking, AccountASaving);

            Console.WriteLine(Bob);
            Console.WriteLine(Alice);
            AccountBobChecking.deposit(10);
            AccountASaving.setInterest(1);
            Console.WriteLine(Bob);
            Console.WriteLine(Alice);
            AccountBobChecking.withdraw(9);
            //Now I try to withdraw again
            AccountBobChecking.withdraw(8); //It bounces back!
            Console.WriteLine(Bob);
            AccountAChecking.deposit(100);
            Console.WriteLine(Alice);


            Console.ReadLine();
          

           


            void PrintString()
            {
                throw new NotImplementedException(); //In Case
            }
        }
    }
}

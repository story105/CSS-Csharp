﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CheckingsAccountAssignmentCharlesStory
{
    class Checkings : Account 
    {
       
        public Checkings(int balance):base(balance)
        {

        }
        public override string ToString()
        {
            return "Checking Account balance: " + balance;

        }
    }
}
